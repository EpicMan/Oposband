The text documentation is automatically generated from the /lib/help/ 
documentation files. Begin browsing on start.txt. But note that the 
plaintext help will contain none of the formatting and links present 
in the standard documentation. It is highly recommended you browse the 
html help instead. Or, even better, browse the helpfiles from within
the game itself :)